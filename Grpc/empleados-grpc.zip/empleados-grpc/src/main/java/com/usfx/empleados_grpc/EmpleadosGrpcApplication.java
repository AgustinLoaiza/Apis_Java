package com.usfx.empleados_grpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleadosGrpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpleadosGrpcApplication.class, args);
	}

}
